##############################
##     Boot test_script     ##
##############################
$: << "#{LOAD_PATH}/app"
require "service_manager"

$state = "booted"